import os
import json
from datetime import datetime, timedelta
import sys

# --- 설정 --- 
INTERVAL_SECONDS = 3 * 60 * 60  # 3시간을 초 단위로 설정
TEST_MODE = True

# 데이터 파일 경로 설정
data_path = os.path.join(os.path.dirname(__file__), "data", "dummy_weather.json")

# 1. 마지막 수집 시간 확인
if not TEST_MODE and os.path.exists(data_path):
    try:
        with open(data_path, "r", encoding="utf-8") as f:
            last_data = json.load(f)
        
        last_updated_str = last_data.get("updated")
        if last_updated_str:
            last_updated_time = datetime.strptime(last_updated_str, "%Y-%m-%d %H:%M")
            current_time = datetime.now()
            time_difference = current_time - last_updated_time
            
            # 3시간 체크 로직
            if time_difference < timedelta(seconds=INTERVAL_SECONDS):
                print(f"[INFO] 마지막 수집 시간으로부터 {time_difference}가 지나지 않아 스크립트를 종료합니다.")
                sys.exit(0)
    except Exception as e:
        print(f"[WARN] 이전 데이터 파일 로드 중 오류 발생: {e}")

# 2. 3시간 이상 경과했거나, 파일이 없으면 데이터 수집 진행
print("\n[INFO] 3시간 이상 경과 또는 초기 실행. 날씨 데이터를 수집합니다...")
temperature = 25
cloud_cover = "구름 조금"

data = {
    "temperature": temperature,
    "cloud": cloud_cover,
    "updated": datetime.now().strftime("%Y-%m-%d %H:%M")
}

os.makedirs(os.path.dirname(data_path), exist_ok=True)
with open(data_path, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False)

print("수집 완료. 데이터가 성공적으로 업데이트되었습니다.")